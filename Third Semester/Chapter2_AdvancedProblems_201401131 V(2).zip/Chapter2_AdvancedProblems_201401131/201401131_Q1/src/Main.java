public class Main
{
 public static void main(String args[])
 {
	 int Arr[]={7,8,9,10,11,12,0,1,2,3};
	 System.out.println(rotated_binary_search(Arr,Arr.length,3));
 }
 public static int rotated_binary_search(int A[], int N, int key)
 {	  
	 int L = 0;
	  int R = N - 1;
	  while (L <= R) {
	    int M = L + ((R - L) / 2);
	    if (A[M] > A[M+1]) 
	    	return A[M];
	    if(A[L]>A[M])
	    	R=M-1;
	    else 
	    	L=M+1;
	  }
	  return -1;
	}
}