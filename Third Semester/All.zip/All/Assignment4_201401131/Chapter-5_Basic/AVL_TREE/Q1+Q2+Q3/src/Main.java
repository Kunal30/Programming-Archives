import java.util.*;
public class Main {
	public static void main(String[] args)
	{
		BST bst = new BST();
        bst.insertavl(5);
        bst.insertavl(4);
        bst.insertavl(3);
        bst.insertavl(2);
        bst.deleteavl(2);
	}
}
