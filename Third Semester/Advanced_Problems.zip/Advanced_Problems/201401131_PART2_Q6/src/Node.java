public class Node {
Node next;
Node prev;
Object data;
public Node(Object data)
{
	next=null;
	prev=null;
	this.data=data;
}
}