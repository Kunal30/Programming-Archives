public class Node {
Node next;
Object data;
public Node(Object data)
{
	next=null;
	this.data=data;
}
}
